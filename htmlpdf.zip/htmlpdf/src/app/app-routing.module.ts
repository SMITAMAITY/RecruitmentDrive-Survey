import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HtmltoimageComponent } from './htmltoimage/htmltoimage.component';
import { HtmltopdfComponent } from './htmltopdf/htmltopdf.component';
import { HtlmimagetopdfComponent } from './htlmimagetopdf/htlmimagetopdf.component';
import { PdfComponent } from './pdf/pdf.component';


const routes: Routes = [
  { path:'toimage', component: HtmltoimageComponent },
  { path:'topdf', component: HtmltopdfComponent },
  { path:'imagetopdf', component: HtlmimagetopdfComponent },
  {  path:'', component: PdfComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
