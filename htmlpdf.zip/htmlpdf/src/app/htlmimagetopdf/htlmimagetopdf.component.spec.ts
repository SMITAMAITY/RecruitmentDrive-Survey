import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtlmimagetopdfComponent } from './htlmimagetopdf.component';

describe('HtlmimagetopdfComponent', () => {
  let component: HtlmimagetopdfComponent;
  let fixture: ComponentFixture<HtlmimagetopdfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtlmimagetopdfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtlmimagetopdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
