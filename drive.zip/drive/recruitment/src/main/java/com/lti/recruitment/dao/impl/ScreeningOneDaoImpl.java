package com.lti.recruitment.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.recruitment.dao.IScreeningOneDao;
import com.lti.recruitment.models.ScreeningOne;

@Repository
public class ScreeningOneDaoImpl implements IScreeningOneDao {
	@PersistenceContext
	@Autowired
	private EntityManager entityManager;
	
	public ScreeningOneDaoImpl() {

	}
	@Override
	public List<ScreeningOne> readAllScreeningOneDetails() {
		String jpql = "From ScreeningOne";
		TypedQuery<ScreeningOne> tquery = entityManager.createQuery(jpql, ScreeningOne.class);
		System.out.println(tquery);
		return tquery.getResultList();
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void createScreeningOneDetails(ScreeningOne screeningOne) {
		entityManager.persist(screeningOne);
		
	}

	
	
}
