import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HtmltoimageComponent } from './htmltoimage/htmltoimage.component';
import { HtmltopdfComponent } from './htmltopdf/htmltopdf.component';
import { HtlmimagetopdfComponent } from './htlmimagetopdf/htlmimagetopdf.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { PdfComponent } from './pdf/pdf.component';

@NgModule({
  declarations: [
    AppComponent,
    HtmltoimageComponent,
    HtmltopdfComponent,
    HtlmimagetopdfComponent,
    PdfComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgApexchartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
