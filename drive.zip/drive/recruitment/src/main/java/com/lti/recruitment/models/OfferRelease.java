package com.lti.recruitment.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="offer_release")
public class OfferRelease {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="Form_id_fourteen")
	private int formIdFourteen; 
	
	@Column(name ="mail")
	private String mail; 
	
	@Column(name ="Name")
	private String Name; 
	
	@Column(name ="status")
	private String status; 
	
	@Column(name ="releasestatus")
	private String releasestatus;

	public int getFormIdFourteen() {
		return formIdFourteen;
	}

	public void setFormIdFourteen(int formIdFourteen) {
		this.formIdFourteen = formIdFourteen;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReleasestatus() {
		return releasestatus;
	}

	public void setReleasestatus(String releasestatus) {
		this.releasestatus = releasestatus;
	}

	public OfferRelease() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OfferRelease(int formIdFourteen, String mail, String name, String status, String releasestatus) {
		super();
		this.formIdFourteen = formIdFourteen;
		this.mail = mail;
		Name = name;
		this.status = status;
		this.releasestatus = releasestatus;
	}

	@Override
	public String toString() {
		return "OfferRelease [formIdFourteen=" + formIdFourteen + ", mail=" + mail + ", Name=" + Name + ", status="
				+ status + ", releasestatus=" + releasestatus + "]";
	} 


}
