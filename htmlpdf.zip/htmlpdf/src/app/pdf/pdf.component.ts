import { Component, OnInit, ElementRef ,ViewChild} from '@angular/core';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';


import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexXAxis,
  ApexPlotOptions,
  ApexStroke
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
};

@Component({
  selector: 'app-pdf',
  templateUrl: './pdf.component.html',
  styleUrls: ['./pdf.component.css']
})
export class PdfComponent {
  blobCopy:Blob;
  title = 'angular-tour-of-fileupload';
  formData: any = {
    email: null,
    Outcome: null,
    userID: '1',
    blobDetailsIng: null
  }
  @ViewChild("chart") chart: ChartComponent;
  public chartOptions: Partial<ChartOptions>;

  constructor() {
    this.chartOptions = {
      series: [
        {
          name: "serie1",
          data: [44, 55, 41, 64, 22, 43, 21]
        },
        {
          name: "serie2",

          data: [53, 32, 33, 52, 13, 44, 32]
        }
      ],
      chart: {
        type: "bar",
        height: 430
      },
      plotOptions: {
        bar: {
          horizontal: true,
          dataLabels: {
            position: "top"
          }
        }
      },
      dataLabels: {
        enabled: true,
        offsetX: -6,
        style: {
          fontSize: "12px",
          colors: ["#fff"]
        }
      },
      stroke: {
        show: true,
        width: 1,
        colors: ["#fff"]
      },
      xaxis: {
        categories: [2001, 2002, 2003, 2004, 2005, 2006, 2007]
      }
    };
  }

  sendblobtoserver(blobdata) {

    let formData:FormData = new FormData();
    console.log(blobdata);

    var fileOfBlob = new File([blobdata], 'aFileName.pdf');
    formData.append("blobDetailsIng", fileOfBlob,fileOfBlob.name);
    formData.append("abc", "testin string");
    console.log(formData);
    console.log(fileOfBlob);
  }
 

  public exportToPng()
  {
    html2canvas(document.body).then( (canvas) => {
   
      canvas.toBlob( (blob2) => {
 
       
             console.log(blob2);
             this.formData.blobDetailsIng = new File([blob2], 'aFileName.pdf');
 
            
           },'image/pdf');
         });

        
  }
  
  


}
   
    
  

